function [centers, widths] = basisfunction_centers(n_basis_functions,time,alpha)
% Get the equidistant centers and widths of a set of basis functions
% Input:
%   n_basis_functions - number of basis functions
%   time              - length of the movement in time
%   alpha             - canonical system parameter
% Output:
%   centers - centers of the basis functions
%   widths  - widths of the basis functions

  % Basis functions centers are approximately equidistantly spaced in phase space 1->0
  % Centers in time space (1 extra to be able to do diff later)
  centers_time = time/(n_basis_functions-1)*(0:n_basis_functions);
  % Compute centers in phases space from equidistant centers in time space
  centers = exp(-alpha*centers_time/time);
  % Compute widths from centers
  widths = 0.5*abs(diff(centers));
  % Remove the extra center used to compute the widths with diff
  centers  = centers(1:end-1);
end
