function trajectory = demonstrations(t_ori_pos)

% This function is used to compute the demonstration data
% Input:
%   t_ori_pos          - time, position and orientation

% Output:
% trajectory   

%%% position part
trajectory.t = t_ori_pos(:,1); % load time samples
trajectory.y =t_ori_pos(:,6:end); % load tip position
trajectory.yd = [0,0,0;diff(trajectory.y)]; % compute velocity
trajectory.ydd = [0,0,0;diff(trajectory.yd)]; % copute acceleration


%%% orientation part
trajectory.q=t_ori_pos(:,2:5);  % load reference orientation [quaternion form]
trajectory.g0=trajectory.q(end,:); % goal orientation
trajectory.tau=trajectory.t(end); % temporal scaling factor

%%% calculation of eta and eta_dot
x=zeros(length(trajectory.t),4); % initals x
for j=1:1:length(trajectory.t)
    x(j,:)=2*quatlog(quatnormalize(quatmultiply(trajectory.g0,quatconj(trajectory.q(j,:)))));
    trajectory.omega(j,:)=x(j,2:4); % quaternion with 0 scalar
    trajectory.eta(j,:)=trajectory.tau*trajectory.omega(j,:);
end

trajectory.eta_dot=[0 0 0;trajectory.tau*diff(trajectory.eta)]; %%
trajectory.R0=quat2rotm(trajectory.q(1,:)); % compute initial orientation matrix
trajectory.Rg=quat2rotm(trajectory.q(end,:)); % compute goal orientation matrix
trajectory.Kd=diag(vex(logm(trajectory.Rg*trajectory.R0'))); % compute matrix Kd

end







