function a = avoid_obstacle(x,v,obs)
% This function is used to avoid obstacle based on coupling term
% Input:
%   x          - tip position
%   v          - tip velocity
%   o          - obstacle position
% Output:
% a            - the repulsive term to keep the robot's tip away from
% obstacle

%gains
gamma = 500;
beta =1;

for k=1:size(obs,1) % loop for multiple obstacle avoidance
   u = obs(k,1:3)-x; %% distance between obstacle and the robot's tip
end
phi = atan2(norm(cross(u,v)),dot(u,v)); % steering angle
r = cross(u,v);
if(r==0)
    R=eye(3);
else
R = angvec2r(pi/2,r);
end
a = gamma*R*v'*phi*exp(-beta*phi); 
end
