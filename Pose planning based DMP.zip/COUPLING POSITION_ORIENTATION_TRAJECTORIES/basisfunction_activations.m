function activations = basisfunction_activations(n_basis_functions,centers,widths,s)
% Compute basis activations for 1 or more time steps
% Input:
%   centers - centers of the basis functions
%   widths  - widths of the basis functions
%   xs      - if scalar: current phase (or time)
%             if vector: sequence of phases (or time)
% Output:
%  activations - activations of the basis functions at each time step

activations = zeros(length(s),n_basis_functions);
for bb=1:n_basis_functions
  activations(:,bb) = exp((-0.5/(widths(bb).^2)) * (s - centers(bb)).^2);
end


end