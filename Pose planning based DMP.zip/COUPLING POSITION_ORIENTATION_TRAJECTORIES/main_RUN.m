% Author:  Ibrahim A. Seleem
% Website: https://www.researchgate.net/profile/Ibrahim-Seleem
% 
% Permission is granted to copy, distribute, and/or modify this program
% under the terms of the GNU General Public License, version 2 or any
% later version published by the Free Software Foundation.
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
% Public License for more details
%
% If you use this code in the context of a publication, I would appreciate 
% it if you could cite it as follows:
%
% @article{seleem2023imitation,
%   title={Imitation-Based Motion Planning and Control of a Multi-Section Continuum Robot Interacting With the Environment},
%   author={Seleem, Ibrahim A and El-Hussieny, Haitham and Ishii, Hiroyuki},
%   journal={IEEE Robotics and Automation Letters},
%   volume={8},
%   number={3},
%   pages={1351--1358},
%   year={2023},
%   publisher={IEEE}
% }
% }

% Mant thanks to:  Freek Stulp, Robotics and Computer Vision, ENSTA-ParisTech https://github.com/stulp/dmpbbo
%%

clear;
close all;
clc;

load('TipPose_manipulator'); % load the demonstrated motion
trajectory = demonstrations(t_ori_pos); % compute v,vdot, eta,etadot

% run learning process with number of basis function=100
[trajectory,trajectory3,y0,g0,obstacle,obs] = IbMP_approach(trajectory,100);



%% plotting
figure(1) % plot the learned position versus the demonstrated orientation
plot3(trajectory.y(:,1),trajectory.y(:,2),trajectory.y(:,3),'color','r','LineWidth',3);
hold on
plot3(trajectory3.y(:,1),trajectory3.y(:,2),trajectory3.y(:,3),'color',	'b','LineWidth',3);
hold on
plot3(y0(1),y0(2),y0(3),'o','Color',rand(1,3),'MarkerSize',10,'DisplayName','Start','LineWidth',2);
hold on
plot3(g0(1),g0(2),g0(3),'x','Color','g','MarkerSize',25,'DisplayName','Goal','LineWidth',2);
hold on
if(obstacle==true) % uncomment to draw obstacles
    for i=1:size(obs,1)
        ellipsoid(obs(i,1),obs(i,2),obs(i,3),obs(i,4),obs(i,5),obs(i,6))
    end
end
xlabel('X [cm]','FontSize',14,'FontWeight','bold')
ylabel('Y [cm]','FontSize',14,'FontWeight','bold')
zlabel('Z [cm]','FontSize',14,'FontWeight','bold')
grid on
legend({'Demonstrated trajectory','Learned trajectory','Initial position','Goal position'},'FontSize',12,'FontWeight','bold') % uncomment to show legened


figure(2) % tracking error
plot(trajectory.t,trajectory.y(:,1)-trajectory3.y(:,1),'k','LineWidth',3)
hold on
plot(trajectory.t,trajectory.y(:,2)-trajectory3.y(:,2),'g','LineWidth',3)
hold on
plot(trajectory.t,trajectory.y(:,3)-trajectory3.y(:,3),'m','LineWidth',3)
grid on
xlabel('Time [s]','FontSize',14,'FontWeight','bold')
ylabel('Error [cm]','FontSize',14,'FontWeight','bold')
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',14)
legend({'X-coordinate','Y-coordinate','Z-coordinate'},'FontSize',12,'FontWeight','bold')
ax = gca;
% ax.GridLineStyle = '-'
% ax.GridColor = 'k'
ax.GridAlpha = 0.35; % maximum line opacity
     
     %% ORIENTATION GRAPHS
figure(3) % plot the learned orientation versus the demonstrated orientation
subplot(2,2,1);
plot(trajectory.t,trajectory.q(:,1),'b','LineWidth',3)
hold on
plot(trajectory.t,trajectory3.q(:,1),'-r','LineWidth',3)
grid on
ylabel('q_0','FontSize',12,'FontWeight','bold')
% hold on
ylh = get(gca,'ylabel');
ylp = get(ylh, 'Position');
set(ylh, 'Rotation',0, 'Position',ylp, 'VerticalAlignment','middle', 'HorizontalAlignment','right')
legend({'Desired trajectory','Learned trajectory'},'FontSize',12,'FontWeight','bold','Location', 'NorthWest')

subplot(2,2,2);
plot(trajectory.t,trajectory.q(:,2),'b','LineWidth',3)
hold on
plot(trajectory.t,trajectory3.q(:,2),'-r','LineWidth',3)
grid on
ylabel('q_1','FontSize',12,'FontWeight','bold')
ylh = get(gca,'ylabel');
ylp = get(ylh, 'Position');
set(ylh, 'Rotation',0, 'Position',ylp, 'VerticalAlignment','middle', 'HorizontalAlignment','right')

subplot(2,2,3);
% grid on
% grid on
plot(trajectory.t,trajectory.q(:,3),'b','LineWidth',3)
hold on
plot(trajectory.t,trajectory3.q(:,3),'-r','LineWidth',3)
axis([0 10  -0.06 0.1])
xticks([0 2 4 6 8 10])
grid on
xlabel('Time [s]','FontSize',12,'FontWeight','bold')
ylabel('q_2','FontSize',12,'FontWeight','bold')
ylh = get(gca,'ylabel');
ylp = get(ylh, 'Position');
set(ylh, 'Rotation',0, 'Position',ylp, 'VerticalAlignment','middle', 'HorizontalAlignment','right')


subplot(2,2,4);
% grid on
plot(trajectory.t,trajectory.q(:,4),'b','LineWidth',3)
hold on
plot(trajectory.t,trajectory3.q(:,4),'-r','LineWidth',3)
grid on
xlabel('Time [s]','FontSize',12,'FontWeight','bold')
ylabel('q_3','FontSize',12,'FontWeight','bold')
ylh = get(gca,'ylabel');
ylp = get(ylh, 'Position');
set(ylh, 'Rotation',0, 'Position',ylp, 'VerticalAlignment','middle', 'HorizontalAlignment','right')


figure(4) % tracking error of orientation
plot(trajectory.t,trajectory.q(:,1)-trajectory3.q(:,1),'y','LineWidth',3)
hold on
plot(trajectory.t,trajectory.q(:,2)-trajectory3.q(:,2),'m','LineWidth',3)
hold on
plot(trajectory.t,trajectory.q(:,3)-trajectory3.q(:,3),'c','LineWidth',3)
hold on
plot(trajectory.t,trajectory.q(:,4)-trajectory3.q(:,4),'g','LineWidth',3)

grid on
xlabel('Time [s]','FontSize',14,'FontWeight','bold')
ylabel('Error [cm]','FontSize',14,'FontWeight','bold')
% % zticks([5 10 15 25 35])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',14)
legend({'$q_0$','${q_1}$','${q_2}$','${q_3}$'},'interpreter','latex','FontSize',12,'FontWeight','bold')
ax = gca;
% ax.GridLineStyle = '-'
% ax.GridColor = 'k'
ax.GridAlpha = 0.35; % maximum line opacity
