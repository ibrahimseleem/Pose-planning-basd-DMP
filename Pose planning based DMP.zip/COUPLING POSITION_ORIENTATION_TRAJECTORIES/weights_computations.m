function [ theta,theta1,activations] = weights_computations(y,yd,ydd,eta,eta_dot,omega,n_basis_functions,...
                                                 s,trajectory,alpha,y0,g0,alpha_z,beta_z,alpha_z1,beta_z1)


%-------------------------------------------------------------------------------

%-------------------------------------------------------------------------------
% Compute basis function activations

  % Get centers and widths
 [centers,widths] = basisfunction_centers(n_basis_functions,trajectory.tau,alpha);
% Compute activations
 activations = basisfunction_activations(n_basis_functions,centers,widths,s);

% compute the target forces
 f_targetp = (-alpha_z*(beta_z*(g0-y)-yd) + trajectory.tau*ydd)./(g0-y0); %% position
 f_target=((trajectory.Kd)\((trajectory.tau.*eta_dot)+(alpha_z1.*eta)-(alpha_z1*beta_z1.*omega))')'; %%orientation

% Compute the regression, using linear least squares
%   (http://en.wikipedia.org/wiki/Linear_least_squares)
 vs_repmat = repmat(s',n_basis_functions,1);
 sum_activations = repmat(sum(abs(activations),2)',n_basis_functions,1);
 activations_normalized = activations' ./ sum_activations;
 vs_activ_norm = vs_repmat.*activations_normalized;
 small_diag = diag(ones(n_basis_functions,1)*1e-10);
 AA = inv(vs_activ_norm*vs_activ_norm' + small_diag)*vs_activ_norm ;
 theta = (AA.* f_targetp); % the learned weights, position trajectory
 theta1 = (AA.* f_target); % the learned weights, orientation trajectory
end