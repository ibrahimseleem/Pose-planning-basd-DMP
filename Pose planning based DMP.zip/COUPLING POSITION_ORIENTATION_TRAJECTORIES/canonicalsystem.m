function s = canonicalsystem(trajectory,alpha,exq)
% Integrate a canonical system 
% Input:
%   trajectory          
%   alpha    - time constant
%   exq      - tracking error
% Output:
%   s - phase stopping variable


zeta=1;
% Closed form solution to 1st order canonical system
s  = exp(-alpha*trajectory.t(1)/(trajectory.tau*(1+1*(zeta*(exq)))));
end



