function [trajectory,trajectory3,y0,g0,obstacle,obs] = IbMP_approach(trajectory,n_basis_functions)
% This function is the learning approach
% Input:
%   trejectory          - the reference demonstrations
%   n_basis_functions          - Number of basis functions
% Output:
% trajectory         
% trajectory3     - The learned trajectories       
% y0 - initial psoition
% g0 - goal position
% obstacle 
% obs - obstacle position

%% learning of the tip position trajectory
% Integrate canonical system in closed form
dt = mean(diff(trajectory.t)); % sampling time
y0 = trajectory.y(1,:); %initial position
g0  = trajectory.y(end,:); % goal position
gn=g0; % continous goal

trajectory3.y=y0; % initial of actual position
trajectory3.yd=[0 0 0]; % initial of actual velocity
trajectory3.ydd=[0 0 0]; % initial of actual acceleration

%%% gains for learning the tip position
alpha=1.00019959032654;
alpha_z = 100.0;
beta_z = alpha_z/4.0;  % to ensure that the system is crtically actuated, beta_z=alpha_z/4

%%% avoiding obstacle
obstacle=false; % true for avoiding obstacle, false for non obstacle
obs=[5.52318552461710,25.4238713093660,31.1014812699883,0.5,0.5,0.5]; % obstacle position



%% learning of the tip orientation trajectory

trajectory3.q(1,:)=trajectory.q(1,:); % initial of actual orientation
trajectory3.eta(1,:)=[trajectory.eta(1,1) trajectory.eta(1,2) trajectory.eta(1,3)];
trajectory3.omega(1,:)=[trajectory.omega(1,1) trajectory.omega(1,2) trajectory.omega(1,3)];

% % uncomment for new goal orientation
% alphag0=diag([767.669890447755,993.019633780239,999.951081910259,999.928405689573]);
alpha_z1=500; % gains
beta_z1=450;

dis=false; % true to add disturbance to orientation


%% start learning algorithm
for i=1:1:length(trajectory.t)

%%% compute the phase stopping variable

   ex0=norm(trajectory.y(end,:)-trajectory3.y(i,:)); 
   ex=norm(trajectory.y(i,:)-trajectory3.y(i,:));


   if(quatnormalize(quatmultiply(trajectory.g0,quatconj(trajectory3.q(i,:))))==[1 0 0 0])
     eq0=2*pi; 
   else
     eq0=2*norm(quatlog(quatnormalize(quatmultiply(trajectory.g0,quatconj(trajectory3.q(i,:))))));
   end

   if(quatnormalize(quatmultiply(trajectory.q(i,:),quatconj(trajectory3.q(i,:))))==[1 0 0 0])
     eq=2*pi;
   else
    eq=2*norm(quatlog(quatnormalize(quatmultiply(trajectory.q(i,:),quatconj(trajectory3.q(i,:))))));  
   end

   exq=ex0+ex+eq0+eq; %% error signal to synchronise poisition and orientation simi
   s = canonicalsystem(trajectory,alpha,exq); % phase stopping variable



%%% calcualte desired force (position+unitquaternion)
   [theta,theta1,activations] = weights_computations(trajectory.y(i,:),trajectory.yd(i,:),trajectory.ydd(i,:),...
                                       trajectory.eta(i,:),trajectory.eta_dot(i,:),trajectory.omega(i,:),...
                                       n_basis_functions,s,trajectory,alpha,y0,g0,...
                                       alpha_z,beta_z,alpha_z1,beta_z1);



%%% compute the force functions
   weighted_sum_activations_pos = sum(activations*theta,3);
   sum_activations = sum(activations,2);
   f = (weighted_sum_activations_pos./sum_activations).*s; % force function, position trajectory

   weighted_sum_activations_ori = sum(activations*theta1,3);
   f1= (trajectory.Kd*((weighted_sum_activations_ori'./sum_activations).*s))'; % force function, orientation trajectory




   if (i<length(trajectory.t))
    
      nonlinear = f.*(g0-y0);  % NONLIN_GOAL

     if obstacle==true
       ya = avoid_obstacle(trajectory3.y(i,:),trajectory3.yd(i,:),obs);
       trajectory3.ydd(i+1,:) = (alpha_z*(beta_z*(gn(i,:)-trajectory3.y(i,:))-trajectory3.yd(i,:)) + nonlinear+ya' )/trajectory.tau;
     else
       trajectory3.ydd(i+1,:) = (alpha_z*(beta_z*(gn(i,:)-trajectory3.y(i,:))-trajectory3.yd(i,:)) + nonlinear )/trajectory.tau;
     end
  
     alpha_g=10;
  
     gds= alpha_g*(g0-gn(i,:))/trajectory.tau; % continous goal equation, position 
     gn(i+1,:)  =  gn(i,:) + dt*gds;
  
    % Integrate acceleration to get velocity and position
     trajectory3.yd(i+1,:) = trajectory3.yd(i,:) + dt*trajectory3.ydd(i+1,:);
     trajectory3.y(i+1,:)  =  trajectory3.y(i,:) + dt* trajectory3.yd(i+1,:);
  
    %%%% orientation section
     eta_rdot=((alpha_z1*((beta_z1*trajectory3.omega(i,:))-trajectory3.eta(i,:))) +f1)/trajectory.tau;
     trajectory3.eta(i+1,:)=trajectory3.eta(i,:)+(dt*eta_rdot);
     r= (dt*([0 trajectory3.eta(i+1,:)]+(0.01*2*(quatlog(quatnormalize(quatmultiply(trajectory.g0,quatconj(trajectory3.q(i,:)))))+...
             quatlog(quatnormalize(quatmultiply(trajectory.q(i,:),quatconj(trajectory3.q(i,:))))))')'))/(2*trajectory.tau);
   
    %%% ADD STEP DISTURBANCE TO OUTPUT
     if dis==true
        if (2<=trajectory.t(i))&&(trajectory.t(i)<=5) %% time period of disturbance
         xxb=0.01; % amplitude of disturbance
        else
         xxb=0;
        end
    
       trajectory3.q(i+1,:)= quatnormalize(quatmultiply(quatexp(r),trajectory3.q(i,:))+xxb);%% add step disturbance
     else
       trajectory3.q(i+1,:)= quatnormalize(quatmultiply(quatexp(r),trajectory3.q(i,:)));%% add step disturbance
     end

     %%% uncomment to define new orientation goal
      % r1= (dt*alphag0*(quatlog(quatnormalize(quatmultiply(trajectory.g0new,quatconj(trajectory.g0)))))')/(tau);
      % trajectory3.g0= quatmultiply(quatexp(r1'),trajectory.g0);       

     xx(i,:)=2*quatlog(quatnormalize(quatmultiply(trajectory.g0,quatconj(trajectory3.q(i+1,:)))));
     trajectory3.omega(i+1,:)=xx(i,2:4);  
     trajectory3.eta(i+1,:)=trajectory.tau*trajectory3.omega(i+1,:);
  else
    break;
  end

end

end